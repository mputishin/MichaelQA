package com.volia;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.opera.OperaDriver;

public class Test_B {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.opera.driver", "D:\\MyProjectJava\\Driver\\chromedriver_win32\\chromedriver.exe");
        WebDriver webDriver = new OperaDriver();

        String url = "http://prestashop-automation.qatestlab.com.ua/admin147ajyvk0/";
        webDriver.get(url);
        webDriver.manage().window().maximize();
        WebElement mail = webDriver.findElement(By.id("email"));
        mail.sendKeys("webinar.test@gmail.com");
        WebElement password = webDriver.findElement(By.name("passwd"));
        password.sendKeys("Xcg7299bnSmMuRLp9ITw");
        WebElement enter = webDriver.findElement(By.className("ladda-label"));
        enter.click();
        Thread.sleep(3000);

        WebElement dashboard = webDriver.findElement(By.linkText("Dashboard"));
        dashboard.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement orders = webDriver.findElement(By.linkText("Заказы"));
        orders.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement clients = webDriver.findElement(By.linkText("Клиенты"));
        clients.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement support = webDriver.findElement(By.linkText("Служба поддержки"));
        support.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement statistics = webDriver.findElement(By.linkText("Статистика"));
        statistics.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement modules = webDriver.findElement(By.linkText("Modules"));
        modules.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement design = webDriver.findElement(By.linkText("Design"));
        design.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement deliver = webDriver.findElement(By.linkText("Доставка"));
        deliver.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement pay = webDriver.findElement(By.linkText("Способ оплаты"));
        pay.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement inter = webDriver.findElement(By.linkText("International"));
        inter.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement shop = webDriver.findElement(By.linkText("Shop Parameters"));
        shop.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        WebElement config = webDriver.findElement(By.linkText("Конфигурация"));
        config.click();
        System.out.println(webDriver.getTitle());
        webDriver.navigate().refresh();
        System.out.println(webDriver.getTitle());

        Thread.sleep(2000);
        webDriver.quit();
    }
}